﻿<#
一键创建 GitHub 仓库并发布 OpenCode Pocket Kit V1.0.1（SSH 连接）

用法：
1. 把本脚本和 一键发布到GitHub.cmd 复制到项目根目录。
2. 确认已安装 Git 和 GitHub CLI。
3. 运行 gh auth login 登录 GitHub。
4. 双击 一键发布到GitHub.cmd。

默认行为：
- 初始化 Git 仓库。
- 提交当前目录内容。
- 创建 GitHub 仓库（使用 SSH 远程地址）。
- 推送 main 分支。
- 创建 V1.0.1 标签。
- 使用 git archive 生成发布 zip。
- 创建 GitHub Release 并上传 zip。
#>

$ErrorActionPreference = "Stop"

# 可按需修改
$RepoName = "opencode-pocket-kit"
$Visibility = "public"      # public 或 private
$DefaultBranch = "main"
$TagName = "V1.0.1"
$ReleaseTitle = "OpenCode Pocket Kit V1.0.1"
$CommitMessage = "release: OpenCode Pocket Kit V1.0.1"
$AssetName = "opencode-pocket-kit-V1.0.1.zip"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Write-Step($Text) {
  Write-Host ""
  Write-Host "== $Text ==" -ForegroundColor Cyan
}

function Require-Command($Name) {
  $cmd = Get-Command $Name -ErrorAction SilentlyContinue
  if (-not $cmd) {
    throw "未找到命令：$Name。请先安装并加入 PATH。"
  }
  return $cmd.Source
}

function Invoke-Native($Command) {
  Write-Host "> $Command" -ForegroundColor DarkGray
  Invoke-Expression $Command
  if ($LASTEXITCODE -ne 0) {
    throw "命令失败，退出码：$LASTEXITCODE`n失败的命令：$Command"
  }
}

# 临时关闭 Stop 模式，避免 gh 命令的错误输出导致脚本终止
function Test-GhRepoExists($FullName) {
  $prevEAP = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  gh repo view $FullName 2>&1 | Out-Null
  $result = $LASTEXITCODE -eq 0
  $ErrorActionPreference = $prevEAP
  return $result
}

function Ensure-NoSecretFilesTrackedRisk {
  $secret = Join-Path $Root "vault\secrets.env.enc"
  if (Test-Path $secret) {
    Write-Warning "检测到 vault\secrets.env.enc。该文件不应提交。请确认 .gitignore 生效。"
  }
}

Write-Step "检查工具"
Require-Command git | Out-Null
Require-Command gh | Out-Null

gh auth status
if ($LASTEXITCODE -ne 0) {
  throw "GitHub CLI 尚未登录。请先运行：gh auth login"
}

$login = (& gh api user --jq .login).Trim()
if (-not $login) { throw "无法读取当前 GitHub 用户名。" }
$RepoFullName = "$login/$RepoName"

Ensure-NoSecretFilesTrackedRisk

Write-Step "初始化 Git 仓库"
if (-not (Test-Path (Join-Path $Root ".git"))) {
  Invoke-Native "git init"
}
Invoke-Native "git config core.quotepath false"
Invoke-Native "git checkout -B $DefaultBranch"

Write-Step "提交文件"
Invoke-Native "git add -A"
$hasStaged = $false
& git diff --cached --quiet
if ($LASTEXITCODE -ne 0) { $hasStaged = $true }
if ($hasStaged) {
  $escapedMessage = $CommitMessage -replace '"', '`"'
  Invoke-Native "git commit -m `"$escapedMessage`""
} else {
  Write-Host "没有新的文件需要提交。"
}

Write-Step "创建或连接 GitHub 仓库"
# SSH 地址格式
$repoUrl = "git@github.com:$RepoFullName.git"

if (Test-GhRepoExists $RepoFullName) {
  Write-Host "仓库已存在：$RepoFullName"
  $origin = (& git remote get-url origin 2>$null)
  if ($LASTEXITCODE -ne 0) {
    Invoke-Native "git remote add origin $repoUrl"
  } else {
    Invoke-Native "git remote set-url origin $repoUrl"
  }
} else {
  Write-Host "仓库不存在，正在创建..."
  $visibilityArg = if ($Visibility -eq "private") { "--private" } else { "--public" }
  # 指定使用 SSH 协议创建远程仓库
  Invoke-Native "gh repo create $RepoName $visibilityArg --git-protocol ssh --source . --remote origin"
}

Write-Step "推送分支"
Invoke-Native "git push -u origin $DefaultBranch"

Write-Step "创建标签"
$localTagExists = $false
# 使用 git show-ref 检查标签是否存在，避免“模糊参数”错误
& git show-ref --tags --verify --quiet "refs/tags/$TagName"
if ($LASTEXITCODE -eq 0) { $localTagExists = $true }

if ($localTagExists) {
  Write-Host "本地标签已存在：$TagName"
} else {
  Invoke-Native "git tag -a $TagName -m `"$ReleaseTitle`""
}
Invoke-Native "git push origin $TagName"

Write-Step "生成发布压缩包"
$DistDir = Join-Path $Root "dist"
New-Item -ItemType Directory -Force $DistDir | Out-Null
$AssetPath = Join-Path $DistDir $AssetName
if (Test-Path $AssetPath) { Remove-Item $AssetPath -Force }
Invoke-Native "git archive --format=zip --output `"$AssetPath`" HEAD"

Write-Step "创建 GitHub Release"
# 临时关闭 Stop 模式，避免 release view 的错误输出导致终止
$prevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& gh release view $TagName 2>&1 | Out-Null
$releaseExists = $LASTEXITCODE -eq 0
$ErrorActionPreference = $prevEAP

if ($releaseExists) {
  Write-Host "Release 已存在，上传或覆盖资源：$TagName"
  Invoke-Native "gh release upload $TagName `"$AssetPath`" --clobber"
} else {
  $notes = @"
OpenCode Pocket Kit V1.0.1

首次发布版本，包含 Windows 便携运行环境、OpenCode、Oh-My-OpenAgent、TUI 插件、Comment Checker、可选 Skills、代理配置、注册命令和加密密钥库脚本。
"@
  $notesFile = Join-Path $DistDir "release-notes-V1.0.1.md"
  Set-Content -Path $notesFile -Value $notes -Encoding UTF8
  Invoke-Native "gh release create $TagName `"$AssetPath`" --title `"$ReleaseTitle`" --notes-file `"$notesFile`""
}

Write-Step "完成"
Write-Host "仓库： https://github.com/$RepoFullName"
Write-Host "发布： https://github.com/$RepoFullName/releases/tag/$TagName"
Write-Host "资源： $AssetPath"
